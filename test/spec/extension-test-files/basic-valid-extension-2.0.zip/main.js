/*global define, console */

define(function (require, exports, module) {
    "use strict";
    
    console.log("Way more powerful than before.");
});