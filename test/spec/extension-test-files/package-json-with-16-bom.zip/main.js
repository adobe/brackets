/*global define, console */

define(function (require, exports, module) {
    "use strict";
    
    console.log("Don't choke on me!");
});