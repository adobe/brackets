/*global define, console */

define(function (require, exports, module) {
    "use strict";
    
});